<?php
namespace App\Entity;
class PropertySearch
{
 private $Nom;
 public function getNom(): ?string
 {
 return $this->Nom;
 }
 public function setNom(string $nom): self
 {
 $this->Nom = $nom;
 return $this;
 }
}